let stream = null;

async function startCamera() {
  const video = document.getElementById("cameraVideo");
  const status = document.getElementById("cameraStatus");
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    video.srcObject = stream;
    video.classList.remove("d-none");
    status.textContent = "Camera ready.";
  } catch (err) {
    status.textContent = "Camera access failed: " + err.message;
  }
}

function captureFrame() {
  const video = document.getElementById("cameraVideo");
  const canvas = document.getElementById("captureCanvas");
  const hidden = document.getElementById("webcam_image");
  const preview = document.getElementById("capturedPreview");
  const status = document.getElementById("cameraStatus");

  if (!video.srcObject) {
    status.textContent = "Start the camera first.";
    return;
  }

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
  hidden.value = dataUrl;
  preview.src = dataUrl;
  preview.classList.remove("d-none");
  status.textContent = "Frame captured.";
}

function stopCamera() {
  const video = document.getElementById("cameraVideo");
  const status = document.getElementById("cameraStatus");
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
    stream = null;
  }
  if (video) video.srcObject = null;
  if (status) status.textContent = "Camera stopped.";
}

window.addEventListener("DOMContentLoaded", () => {
  const startBtn = document.getElementById("startCameraBtn");
  const captureBtn = document.getElementById("captureFrameBtn");
  const stopBtn = document.getElementById("stopCameraBtn");
  if (startBtn) startBtn.addEventListener("click", startCamera);
  if (captureBtn) captureBtn.addEventListener("click", captureFrame);
  if (stopBtn) stopBtn.addEventListener("click", stopCamera);
});
